// GraphicsWorld.h
// ENSF 614 Fall 2022 LAB 5 - EXERCISE A & B
// Created by: Brandon Lac
// Submission Date: October 21 2023
#ifndef GraphicsWorld_H
#define GraphicsWorld_H
class GraphicsWorld
{
public:
    void run();
    // PROMISES: It has outputs to correctly test if the above classes are working.
    //           Also prints the name of the author as well.
};

#endif