#include <iostream>
#include "GraphicsWorld.h"
int main()
{
    GraphicsWorld b = GraphicsWorld();
    b.run();
}
